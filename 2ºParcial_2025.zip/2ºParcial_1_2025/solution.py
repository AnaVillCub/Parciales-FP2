class ContainerBase:
    def __init__(self):
        self.first = None
        self.last = None

class Client:

    def __init__(self, name, total_cost):
        self.name = name
        self.total_cost = total_cost

    def __str__(self):
        return f"{self.name}: {self.total_cost}"


class CheckoutQueue(ContainerBase):
    class Node:
        def __init__(self, value, next=None):
            self.value = value  # El valor en el nodo.
            self.next = next    # El enlace al siguiente nodo.

    def __init__(self):
        self.first = None   # El enlace al primer nodo de la lista.
        self.last = None   # El enlace al último nodo de la lista.
        self.__ingresado = 0

    def enqueue(self, nuevo_cliente):
        nuevo_nodo = self.Node(nuevo_cliente)

        if self.first == None:
            self.first = nuevo_nodo
            self.last = nuevo_nodo
        else:
            self.last.next = nuevo_nodo
            self.last = nuevo_nodo

    def dequeue(self):
        if self.first == None:
            return None
        else:
            retornar = self.first.value
            self.__ingresado += self.first.value.total_cost
            self.first = self.first.next
            return retornar
    
    def view(self):
        if not self.first: print(None)
        else:
            actual = self.first
            while actual:
                print(actual.value)
                actual = actual.next

    @property
    def daily_sales(self):
        return self.__ingresado

    def split(self):
        nueva_cola = CheckoutQueue()
        current = self.first
        while current != None and current.next != None:
            nueva_cola.enqueue(current.next.value)
            current.next = current.next.next
            current = current.next
        return nueva_cola


cola = CheckoutQueue()
# print(cola.view()) # ➡️None⬅️
cola.enqueue(Client("Ana", 35))
cola.enqueue(Client("Luis", 50))
cola.enqueue(Client("Marta", 25))
print(cola.view()) # ➡️[Ana: 35]->[Luis: 50]->[Marta: 25]⬅️->None
print(cola.dequeue()) # Ana: 35
print(cola.dequeue()) # Luis: 50
print(cola.daily_sales) # 85
print(cola.view()) # ➡️[Marta: 25]⬅️->None

print()
print()
print()

cola.enqueue(Client("José", 40))
cola.enqueue(Client("Laura", 60))
cola.enqueue(Client("Javier", 55))
cola.enqueue(Client("Marco", 75))
cola.enqueue(Client("Harry", 70))
print(cola.view()) # ➡️[Marta: 25]->[José: 40]->[Laura: 60]⬅️->None
nueva_cola = cola.split()
print(cola.view()) # ➡️[Marta: 25]->[Laura: 60]⬅️->None
print(nueva_cola.view()) # ➡️[José: 40]⬅️->None
print()