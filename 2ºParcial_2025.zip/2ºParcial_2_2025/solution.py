class ContainerBase:
    def __init__(self):
        self.first = None
        self.last = None

class InterestGroup(ContainerBase):

    class Node:
        def __init__(self, value, next=None):
            self.value = value
            self.next = next

    def __init__(self):
        self.first = None

    def view(self):
        if not self.first: print(None)
        else:
            actual = self.first
            while actual:
                print(actual.value)
                actual = actual.next

    def is_member(self, nombre_buscado):
        actual = self.first
        while actual != None:
            if (actual.value == nombre_buscado):
                return True
            else:
                actual = actual.next
        return False

    def add_member(self, nuevo_nombre):
        if self.is_member(nuevo_nombre):
            return False
        else:
            nuevo_nodo = self.Node(nuevo_nombre, self.first)
            self.first = nuevo_nodo

    @property
    def size(self):
        tamaño = 0
        actual = self.first
        while actual:
            tamaño += 1
            actual = actual.next
        return tamaño

    def remove_member(self, nombre_buscado):
        if not self.is_member(nombre_buscado):
            return False
        else:
            if self.first.value == nombre_buscado:
                self.first = self.first.next
            else:
                actual = self.first
                while (actual != None) and (actual.next != None):
                    if (actual.next.value == nombre_buscado):
                        actual.next = actual.next.next
                    else:
                        actual = actual.next
    
    def union(self, nueva_lista):
        actual = self.first
        while actual:
            if not nueva_lista.is_member(actual.value):
                nueva_lista.add_member(actual.value)
            actual = actual.next
        return nueva_lista







# Creamos dos grupos
group1 = InterestGroup()
group2 = InterestGroup()

# print("Inicialmente:")
# print(group1.view())  # ➡️ None
# print(group2.view())  # ➡️ None

# Añadimos miembros al primer grupo
# group1.is_member("Ana")
group1.add_member("Ana")
group1.add_member("Luis")
group1.add_member("Marta")

print("\nGrupo 1 tras añadir miembros:")
print(group1.view())  # ➡️ [Marta]->[Luis]->[Ana]->None

# Añadimos miembros al segundo grupo
group2.add_member("Mireya")
group2.add_member("Harrinson")
group2.add_member("Ana")

print()
print()
print()
# Unión de grupos
union_group = group1.union(group2)
print("\nUnión de grupo1 y grupo2:")
print(union_group.view())  # ➡️ [Ana]->[Luis]->[Marta]->[Carlos]->[Elena]->None

# # Probar que no se agregan duplicados
# group1.add_member("Luis")  # Ya está
# print("\nGrupo1 tras intentar añadir a 'Luis' otra vez:")
# print(group1.view())  # ➡️ [Ana]->[Luis]->[Marta]->None

# # Probar que no se elimnan membros
# group1.remove_member("Marta")  # Ya está
# print("\nGrupo1 tras eliminar 'Marta':")
# print(group1.view())  # ➡️ [Ana]->[Luis]->None