class ContainerBase:
    def __init__(self):
        self.first = None
        self.last = None


class Task:

    def __init__(self, name, duration):
        self.name = name
        self.duration = duration

    def __str__(self):
        return f"{self.name}: {self.duration} min"


class TaskList(ContainerBase):

    class Node:
        def __init__(self, value, next=None):
            self.value = value
            self.next = next

    def __init__(self):
        self.first = None
        self.last = None
        self.len = 0

    def view(self):
        if not self.first: print(None)
        else:
            actual = self.first
            while actual:
                print(actual.value)
                actual = actual.next

    def add_task(self, nueva_tarea):
        nuevo_nodo = self.Node(nueva_tarea)
        if self.first == None:
            self.first = nuevo_nodo
            self.last = nuevo_nodo
            self.len += 1
        else:
            self.last.next = nuevo_nodo
            self.last = nuevo_nodo
            self.len += 1
    
    def get_task(self, posicion):
        if posicion < 0 or posicion >= self.len:
            return None
        elif posicion == 0:
            retornar = self.first.value
            self.first = self.first.next
            self.len -= 1
            return retornar
        else:
            retornar = None
            indice = 0
            actual = self.first
            while (actual != None) and indice < posicion-1:
                actual = actual.next
                indice += 1
            
            retornar = actual.next.value
            actual.next = actual.next.next
            self.len -= 1
            return retornar

    @property
    def time_left(self):
        actual = self.first
        duracion_total = 0
        while actual != None:
            duracion_total += actual.value.duration
            actual = actual.next
        return duracion_total




t1 = Task("Lavar los platos", 15)
t2 = Task("Hacer la compra", 40)
t3 = Task("Estudiar Python", 120)

lista = TaskList()
lista.add_task(t1)
lista.add_task(t2)
lista.add_task(t3)
print(lista.view()) # ➡️[Lavar los platos: 15 min]->[Hacer la compra: 40 min]->[Estudiar Python: 120 min]->None

print(lista.get_task(1))       # Hacer la compra: 40 min
print(lista.time_left)         # 175