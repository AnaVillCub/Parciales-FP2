"""Escriba aquí su código."""
def digits(cadena):
    for letra in cadena:
        if letra.isnumeric():
            yield letra


if __name__ == "__main__":
    # Escriba aquí el código que quiera probar
    string = "El alunizaje número 1 ocurrió en 1969, en el mes 07"
    for letra in digits(string):
        print(letra)