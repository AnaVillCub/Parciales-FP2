class Nodo:

    def __init__(self, valor):
        self.valor = valor
        self.siguiente = None
        self.anterior = None

class ListasEnlazadas:

    def __init__(self):
        self.cabeza = None
        self.cola = None

    def mostrar_adelante(self):
        actual = self.cabeza
        while actual:
            print(actual.valor)
            actual = actual.siguiente

    def mostrar_detrás(self):
        actual = self.cola
        while actual:
            print(actual.valor)
            actual = actual.anterior

    def agregar_adelante(self, valor):
        nuevo = Nodo(valor)
        
        if not self.cabeza:
            self.cabeza = self.cola = nuevo
        else:
            self.cabeza.anterior = nuevo
            nuevo.siguiente = self.cabeza
            self.cabeza = nuevo

    def agregar_final(self, valor):
        nuevo = Nodo(valor)

        if not self.cabeza:
            self.cabeza = self.cola = nuevo
        else:
            self.cola.siguiente = nuevo
            nuevo.anterior = self.cola
            self.cola = nuevo
    

    def eliminar_primero(self):
        if not self.cabeza.siguiente:
            self.cabeza = None
            self.cola = None
        else:
            self.cabeza = self.cabeza.siguiente
            self.cabeza.anterior = None
    
    def eliminar_ultimo(self):
        if not self.cabeza.siguiente:
            self.cabeza = None
            self.cola = None
        else:
            self.cola = self.cola.anterior
            self.cola.siguiente = None
    
    def buscar_valor(self, valor):
        actual = self.cabeza
        while actual:
            if actual.valor == valor:
                return True
            actual = actual.siguiente
        return False
    
    def insertar_en(self, pos, valor):
        nuevo = Nodo(valor)

        if not self.cabeza:
            self.cabeza = nuevo
            self.cola = nuevo
        else:
            indice = 0
            actual = self.cabeza
            while actual and indice < pos - 1:
                actual = actual.siguiente
                indice += 1
            
            nuevo.siguiente = actual.siguiente
            actual.siguiente = nuevo

    def eliminar_en(self, pos):
        indice = 0
        actual = self.cabeza

        while actual and indice != pos:
            actual = actual.siguiente
            indice += 1
        
        if not actual:
            raise IndexError("Posición fuera de rango")
        
        if actual.anterior == None:
            self.eliminar_primero()
        elif actual.siguiente == None:
            self.eliminar_ultimo()
        else:
            actual.anterior.siguiente = actual.siguiente
            actual.siguiente.anterior = actual.anterior

    def longitud(self):
        cuenta = 0
        actual = self.cabeza

        while actual:
            cuenta += 1
            actual = actual.siguiente

        return cuenta




# Agregar 3 elementos por la cola y uno por la cabeza
lista = ListasEnlazadas()
lista.agregar_final(1)
lista.agregar_final(2)
lista.agregar_final(3)
lista.agregar_adelante(0)
lista.mostrar_adelante()
print()

# Elimina el primer elemento (por la cabeza) y lo muestra
# lista.eliminar_primero()
# lista.eliminar_ultimo()
# lista.mostrar_adelante()
# print()

# Buscar valor (desde la cabeza hasta la cola)
print(lista.buscar_valor(1))
print(lista.buscar_valor(4))
print()

# Insertar un elemento en una posición específica
# lista.insertar_en(2, "Nuevo Elemento")
# lista.mostrar_adelante()

# Eliminar un elemento en una posición específica
lista.eliminar_en(2)
lista.mostrar_adelante()

# Contar cantidad de elementos de una lista doblemente encandenada
print(lista.longitud())