class Nodo:
    def __init__(self, valor):
        self.valor = valor
        self.siguiente = None

class ListaEnlazada:
    def __init__(self):
        self.cabeza = None

    def mostrar(self):
    # Tu código aquí
        actual = self.cabeza
        while actual:
            print(actual.valor)
            actual = actual.siguiente

    def agregar(self, valor):
        nuevo = Nodo(valor)
        nuevo.siguiente = self.cabeza
        self.cabeza = nuevo

    def append(self, valor):
    # Escribe aqui el código
        nuevo = Nodo(valor)
        if not self.cabeza:
            self.cabeza = nuevo
        else:
            actual = self.cabeza
            while actual.siguiente:
                actual = actual.siguiente
            actual.siguiente = nuevo
    
    def contar(self):
        cuenta = 0
        actual = self.cabeza
        while actual:
            cuenta += 1
            actual = actual.siguiente
        return f"En la lista existen {cuenta} elementos"

print("<===== APPEND PARA 6 ELEMENTOS Y MOSTRARLOS =====>\n")
lista1 = ListaEnlazada()
lista1.append("Primer Elemento")
lista1.append("Segundo Elemento")
lista1.append("Tercer Elemento")
lista1.append("Cuarto Elemento")
lista1.append("Quinto Elemento")
lista1.append("Sexto Elemento")
lista1.mostrar()
print()


print("<===== APPEND Y AGREGAR 4 ELEMENTOS =====>\n")
lista2 = ListaEnlazada()
lista2.agregar(10)
lista2.agregar(20)
lista2.append(30)
lista2.append(40)
lista2.mostrar()
print()
# La lista debería ser: 20 -> 10 -> 30 -> 40

print("<===== CONTAR ELEMENTOS DE LA LISTA =====>\n")
print(lista1.contar())
print(lista2.contar())
print()