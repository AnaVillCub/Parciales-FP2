class Nodo:
    def __init__(self, valor):
        self.valor = valor
        self.siguiente = None

class ListaEnlazada:
    def __init__(self):
        self.cabeza = None

    def agregar(self, valor):
        nuevo = Nodo(valor)
        nuevo.siguiente = self.cabeza
        self.cabeza = nuevo

    def mostrar(self):
    # Tu código aquí
        actual = self.cabeza
        while actual:
            print(actual.valor)
            actual = actual.siguiente

    def contar(self):
    # Tu código aquí
        actual = self.cabeza
        cuenta = 0
        while actual:
            cuenta += 1
            actual = actual.siguiente
        return cuenta

    def buscar(self, valor):
    # Tu código aquí
        actual = self.cabeza
        while actual:
            if actual.valor == valor:
                return True
            actual = actual.siguiente
        return False

    def a_lista(self):
    # Tu código aquí
        resultado = []
        actual = self.cabeza
        while actual:
            resultado.append(actual.valor)
            actual = actual.siguiente
        return resultado


# Resultado esperado
lista = ListaEnlazada()

lista.agregar(3)
lista.agregar(2)
lista.agregar(1)

lista.mostrar() # Debería imprimir: 1 2 3 (uno por línea)

print(lista.contar()) 

print(lista.buscar(2))  # True
print(lista.buscar(99)) # False

print(lista.a_lista())  # [1, 2, 3]