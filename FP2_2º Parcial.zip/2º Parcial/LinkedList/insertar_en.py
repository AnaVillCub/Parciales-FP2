class Nodo:
    def __init__(self, valor):
        self.valor = valor
        self.siguiente = None

class ListaEnlazada:
    def __init__(self):
        self.cabeza = None

    def mostrar(self):
    # Tu código aquí
        actual = self.cabeza
        while actual:
            print(actual.valor)
            actual = actual.siguiente

    def agregar(self, valor):
        nuevo = Nodo(valor)
        nuevo.siguiente = self.cabeza
        self.cabeza = nuevo

    def append(self, valor):
    # Escribe aqui el código
        nuevo = Nodo(valor)
        if not self.cabeza:
            self.cabeza = nuevo
        else:
            actual = self.cabeza
            while actual.siguiente:
                actual = actual.siguiente
            actual.siguiente = nuevo
    
    def contar(self):
        cuenta = 0
        actual = self.cabeza
        while actual:
            cuenta += 1
            actual = actual.siguiente
        return f"En la lista existen {cuenta} elementos"

    def insertar_en(self, pos, valor):
        nuevo = Nodo(valor)

        if pos == 0:
            nuevo.siguiente = self.cabeza
            self.cabeza = nuevo
        else:
            actual = self.cabeza
            indice = 0

            while actual and (indice < pos - 1):
                actual = actual.siguiente
                indice += 1
            
            if not actual:
                raise IndexError("Posición fuera de rango")
            
            nuevo.siguiente = actual.siguiente
            actual.siguiente = nuevo


lista = ListaEnlazada()
lista.append(10)
lista.append(20)
lista.append(40)
lista.insertar_en(2, 30)
lista.insertar_en(0, 5)
lista.insertar_en(5, 50)
# Inserta el 3 entre el 2 y el 4
lista.mostrar()

try:
    lista.insertar_en(10, 999)
except IndexError:
    print("¡Error capturado correctamente!")