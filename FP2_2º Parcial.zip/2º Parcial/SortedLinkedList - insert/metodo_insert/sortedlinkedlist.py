"""Este módulo ofrece una clase para manejar listas encadenadas."""


class SortedLinkedList:
    """Representa una lista simplemente encadenada."""

    class Node:
        """Nodo de una lista simplemente encadenada."""

        def __init__(self, value, next_node=None):
            """Cada nodo tiene un valor y un enlace al siguiente nodo."""
            self.value = value
            self.next_node = next_node

    def __init__(self):
        """Incializa una lista vacía."""
        self.__first = None
        self.__len = 0

    def __len__(self):
        """Devuelve el número de elementos de la lista."""
        return self.__len

    def __iter__(self):
        """Generdor para recorrer la lista."""
        current = self.__first

        while current is not None:
            yield current.value
            current = current.next_node

    # Escriba aquí el código pedido.

    def append(self, value):
        new_node = self.Node(value)
        current = self.__first

        if not self.__first:
            self.__first = new_node

        while current:
            current = current.next_node

        current.next_node = new_node
        self.__len += 1

    def insert(self, value):
        new_node = self.Node(value)
        actual = self.__first
        anterior = None

        while actual and actual.value < value:
            anterior = actual
            actual = actual.next_node

        if anterior is None:
            # Insertar al principio
            new_node.next_node = self.__first
            self.__first = new_node
        else:
            # Insertar en medio o final
            new_node.next_node = actual
            anterior.next_node = new_node

        self.__len += 1
