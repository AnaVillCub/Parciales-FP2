"""Escriba aquí su código."""
def diferencial(lista):
    primero = len(lista[0])
    yield primero
    for i in range(1, len(lista)):
        yield len(lista[i]) - primero
        primero = len(lista[i])


if __name__ == "__main__":
    test = ["carmelita", "carmelitas", "casas", "gas", "Manhattan", "manos"]
    for word in diferencial(test):
        print(word)